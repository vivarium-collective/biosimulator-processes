from smoldyn import __version__  # noqa: F401
